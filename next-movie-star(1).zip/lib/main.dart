import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'SecondePage.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Navigation Over Screens',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
//      home: MainPage(),

      // Declare routes
      routes: {
        // Main initial route
        '/': (context) => MainPage(),
        // Second route
        '/second': (context) => SecondPage(),
      },
      initialRoute: '/',
    );
  }
}

class MainPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text('Navigation over screens'),
        ),
        body: Container(
          child: Column(
            children: <Widget>[
              Container(
                child: const Text("Who is The Big next actor/Actress in hollywood?",
                    style: TextStyle(
                      fontSize: 22,
                    ),
                    softWrap: true),
              ),
              SizedBox(height: 22),
              Container(
                child: const Image(image: AssetImage("images/toon.png")),
              ),

              SizedBox(height: 27),
              // Navigate using declared route name
              ElevatedButton(
                onPressed: () => Navigator.pushNamed(context, '/second'),
                child: Text('Details'),
              ),
              SizedBox(height: 27),
              // Navigate using simple push method
              /*
              ElevatedButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SecondPage()),
                ),
                child: Text('Navigate using push method'),
              ),
              */
            ],
          ),
        ),
      );
}
