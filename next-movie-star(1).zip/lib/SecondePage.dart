import 'package:flutter/material.dart';

class SecondPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Scaffold(
        appBar: AppBar(
          title: Text('Second screen'),
        ),
        body: Column(
          children: [
            const SizedBox(height: 27),
            Center(
              child: const Text(
                "Her Name IS......... ",
                style: TextStyle(fontSize: 37, color: Colors.red),
              ),
            ),
            SizedBox(height: 22),
            Center(
              child: Container(
                width: 177,
                height: 177,
                child: const Image(image: AssetImage("images/barb_7.jpg")),
              ),
            ),
            SizedBox(
              height: 27,
            ),
            const Text(
              "Barbara Horvat..... weeheeee  ",
              style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.black),
            ),
            SizedBox(
              height: 27,
            ),
            Container(
              height: 52,
              width: 77,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Back'),
              ),
            ),
          ], // children ends here
        ),
      ),
    );
  }
}
